
<div id="footer">
<!-- footer start -->
<div class="row">
    <div class="col-9">
        <h5>Contact Us</h5>
        <div style="margin-left: 20px;">
        <h6>No:78,Kandy Road, malabe</h6>
        <h6>+94 77 890 7002</h6>
        <h6>viewportaliwt@gmail.com</h6>
        </div>
    </div>
    <div class="col">
        <h5>Follow Us</h5>
        <div class="row" style="font-size: 25px;color:white; padding:0px 25px;">
            <div class="col"><i class="bi bi-facebook"></i></div>
            <div class="col"><i class="bi bi-twitter"></i></div>
            <div class="col"><i class="bi bi-linkedin"></i></div>
            <div class="col"><i class="bi bi-google"></i></div>
        </div>
        <h5>Payement Methods</h5>

    </div>
</div>
</div>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    AOS.init();
</script>


    </body>
</html>