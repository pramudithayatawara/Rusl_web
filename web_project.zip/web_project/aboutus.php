
<!-- include header file -->
<?php include("./header.php") ?>

<!-- AboutUs main contain -->
<div style="display: inline-block;position:relative; ">


    <div class="about-us" style="position: relative;">
       
        <img src="images/hash-images/groupimage.jpg" style="width: 100%; height: 400px; position: relative;">
        <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc maximus, nulla ut commodo sagittis, sapien dui mattis dui, non pulvinar lorem felis nec erat.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc maximus, nulla ut commodo sagittis, sapien dui mattis dui, non pulvinar lorem felis nec erat.
        </p>
    </div>

    <div class="our-mission">
        <h2>Our Mission</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. A corrupti repudiandae ipsum ut consequuntur officiis nulla, eos rem vel voluptas cupiditate ad eveniet suscipit deleniti voluptates earum, magni assumenda sed?</p>
        <button>Read More</button>
    </div>

</div>
<div>

    <div class="our-services">
        <h2>Our Services</h2>
        <div class="services-container">
            <div class="service">
                <img src="./images/hash-images/m1.jpg" width="15%" height="15%">
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Tenetur nostrum obcaecati, molestiae in animi est non vero natus corporis ipsum? Doloremque sint tempora, numquam omnis saepe ab ipsum sunt nostrum?</p>
            </div>
            <div class="service">
                <img src="./images/hash-images/w1.jpg"  width="15%" height="15%">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi inventore obcaecati nesciunt amet labore nobis voluptates sapiente quam laborum quo fugit atque pariatur, aliquam dolorum a veniam laboriosam mollitia saepe.</p>
            </div>
            <div class="service">
                <img src="./images/hash-images/w2.jpg"  width="15%" height="15%">
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptatum id similique sapiente iure maxime? Cupiditate earum reprehenderit, mollitia delectus saepe unde quod eligendi commodi ullam dignissimos praesentium iste repudiandae est.</p>
            </div>
            <div class="service">
                <img src="./images//hash-images/m2.jpg"  width="15%" height="15%">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime in similique tempora, quasi aliquid dolorem enim asperiores totam doloremque nemo earum. Explicabo ducimus possimus, ea repellat eligendi reprehenderit ipsum inventore?</p>
            </div>
            <div class="service">
                <img src="./images/hash-images/w3.jpg"  width="15%" height="15%">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis dolor maiores minima expedita, aut optio aliquid iusto nemo nostrum, aliquam fugit laborum amet quaerat molestiae magni, nisi quia hic magnam.</p>
            </div>
        </div>
      </div>
</body>
</html>

<!-- include footer file -->
<?php include("./footer.php") ?>